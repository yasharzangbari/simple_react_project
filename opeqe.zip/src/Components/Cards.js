import React from 'react';
import { MDBBtn, MDBCard, MDBCardBody, MDBCardImage, MDBCardTitle, MDBCardText, MDBCol } from 'mdbreact';
import TimerIcon from '@material-ui/icons/Timer';

const Cards = (props) => {
  return (
    <MDBCol>
         
      <MDBCard style={{ width: "27rem", padding: "10px", borderRadius: "7px" }}>
        <MDBCardImage className="img-fluid" src={props.menu.image} waves />
        <MDBCardBody>
          <MDBCardTitle>{props.menu.title}</MDBCardTitle>
          <MDBCardText>
          A'la Carte , AmericanMain Course
          </MDBCardText>
            <p style={{float: "left" , fontSize: 12}}> <TimerIcon/> 5-7 Mins ${props.menu.price}</p> 
        </MDBCardBody>
      </MDBCard>
    </MDBCol>
  )
}

export default Cards;

