import React, { Component } from "react";



export default class Caroucel extends Component {
	constructor(props) {
		super(props);
		this.state = {
            service: "",
            activeClass: "",
            active1: "",
            active2: "",
            active3: "",
            
		};
    }
  
   
    componentDidMount(){
       
        var images = [
        "https://cdn.opeqe.com/image/menu/s/45.jpg",
        "https://cdn.opeqe.com/image/menu/s/3.jpg",
        "https://cdn.opeqe.com/image/menu/s/46.jpg"  
            ]
        var services = [ 'Transition Assistace', 'Advocacy and Guidance', 'Respite Care']
        let i = 0;
        var classes = ['active1' , 'active2' , 'active3'];
        
        setInterval(() =>{
            document.getElementById("bacgroundCaroucel").style.backgroundImage = "url(" + images[i] + ")";
            document.getElementById("bacgroundCaroucel").style.backgroundSize = "cover";
            document.getElementById("bacgroundCaroucel").style.backgroundPosition = "center center";
            // document.getElementById().classList.add("active");
          this.setState({
            service: services[i],
            [classes[i]] : "active"
          });
          i++;
          
          if(i >= services.length){
            i = 0;
          }
        }, 2000 );
      }

    
   
	
	render() {
		return (
			<div>
				
                    <div id="bacgroundCaroucel" className="slider1">
                        <p>{this.state.service}</p>
                        <div className="main">
                            <div className="circle">
                                <div   className={this.state.active1 == "" ? null : "active"}></div>
                            </div>
                            <div className="circle">
                                 <div  className={this.state.active2 == "" ? null : "active"}></div>
                            </div>
                            <div className="circle">
                                <div  className={this.state.active3 == "" ? null : "active"}></div>
                            </div>
                        </div>
                    </div>
                    
                
			</div>
		);
	}
}
