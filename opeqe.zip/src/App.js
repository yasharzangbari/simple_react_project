import React, { Component } from "react";
import './App.css';
import Caroucel from "./Components/Caroucel";
import menuItem from "./menu.json";
import Cards from "./Components/Cards";



export default class App extends Component {
	constructor(props) {
		super(props);
		this.state = {
            currentPosition: 0,
            linePosition : 0
		};
    }


    handleClick = (value) => {
        if(value == 1) {
            this.setState({
                currentPosition: this.state.currentPosition + 1400 ,
                linePosition: this.state.linePosition + 335
            } , () => console.log(this.state.currentPosition))
        } else if (value == 2) {
            this.setState({currentPosition: this.state.currentPosition - 1400 , linePosition: this.state.linePosition - 335})
        }
        
    }

 
	
	render() {
		return (
            <div className="App">
            <Caroucel />
            
            {this.state.currentPosition !== 5600 
                ? 
                <div style={{top: "87%" , left : "2%" , zIndex: "1" , marginTop: 40, background: "green" , width: 50, height: 50, borderRadius: 50 , position: "absolute" , }} onClick={() => {this.handleClick(1)}}></div>

                : 
              null
            }
              
            {this.state.currentPosition == 5600
                ? 
                <div 
                style={{top: "87%" , left : "94%" , zIndex: "1" , marginTop: 40, background: "green" , width: 50, height: 50, borderRadius: 50 , position: "absolute" , }} 
                onClick={() => {this.handleClick(2)}}></div>
                :
                null
            }
            

            

       <div className="outer">
           <h2>Salad</h2>
           <div className="divider">

                <div className="line" style={{ transform: `translate(+${this.state.linePosition}px)`, transition: "1s ease-out"}}></div>
           </div>
           <div id="wrap" className="flex" style={{ transform: `translate(-${this.state.currentPosition}px)`, transition: "1s ease-out"}}>
              
               {menuItem.map(menu => {
                   return <div>
                   <Cards menu={menu}/>
                   </div>
               })}
           </div>
         </div>
       
       
           </div>
		);
	}
}



